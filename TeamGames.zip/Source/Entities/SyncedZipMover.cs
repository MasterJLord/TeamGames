
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Microsoft.Xna.Framework;
using Monocle;

namespace Celeste.Mod.TeamGames.Entities;

public class SyncedZipMover : ZipMover
{

	/*
	public static ParticleType P_Scrape;

	public static ParticleType P_Sparks;

	private Themes theme;

	private MTexture[,] edges = new MTexture[3, 3];

	private Sprite streetlight;

	private BloomPoint bloom;

	private ZipMoverPathRenderer pathRenderer;

	private List<MTexture> innerCogs;

	private MTexture temp = new MTexture();

	private bool drawBlackBorder;

	private Vector2 start;

	private Vector2 target;

	private float percent;

	private static Color ropeColor = Calc.HexToColor("663931");

	private static Color ropeLightColor = Calc.HexToColor("9b6157");

	private SoundSource sfx = new SoundSource();
	*/

	public SyncedZipMover(EntityData data, Vector2 offset) : base(data, offset)
	{
		Components.RemoveAll<Coroutine>();
		Add(new Coroutine(Sequence()));
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public override void Added(Scene scene)
	{
		base.Added(scene);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public override void Removed(Scene scene)
	{
		base.Removed(scene);
	}


	private IEnumerator Sequence()
	{
		Vector2 start = Position;
		while (true)
		{
			if (!HasPlayerRider())
			{
				yield return null;
				continue;
			}
			Logger.Log(LogLevel.Debug, "TeamGames/ZipMover", "Zip mover triggered");
			sfx.Play((theme == Themes.Normal) ? "event:/game/01_forsaken_city/zip_mover" : "event:/new_content/game/10_farewell/zip_mover");
			Input.Rumble(RumbleStrength.Medium, RumbleLength.Short);
			StartShaking(0.1f);
			yield return 0.1f;
			streetlight.SetAnimationFrame(3);
			StopPlayerRunIntoAnimation = false;
			float at = 0f;
			while (at < 1f)
			{
				yield return null;
				at = Calc.Approach(at, 1f, 2f * Engine.DeltaTime);
				percent = Ease.SineIn(at);
				Vector2 vector = Vector2.Lerp(start, target, percent);
				ScrapeParticlesCheck(vector);
				if (Scene.OnInterval(0.1f))
				{
					pathRenderer.CreateSparks();
				}
				MoveTo(vector);
			}
			StartShaking(0.2f);
			Input.Rumble(RumbleStrength.Strong, RumbleLength.Medium);
			SceneAs<Level>().Shake();
			StopPlayerRunIntoAnimation = true;
			yield return 0.5f;
			StopPlayerRunIntoAnimation = false;
			streetlight.SetAnimationFrame(2);
			at = 0f;
			while (at < 1f)
			{
				yield return null;
				at = Calc.Approach(at, 1f, 0.5f * Engine.DeltaTime);
				percent = 1f - Ease.SineIn(at);
				Vector2 position = Vector2.Lerp(target, start, Ease.SineIn(at));
				MoveTo(position);
			}
			StopPlayerRunIntoAnimation = true;
			StartShaking(0.2f);
			streetlight.SetAnimationFrame(1);
			yield return 0.5f;
		}
	}

}
